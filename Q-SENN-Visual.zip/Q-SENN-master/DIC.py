import torch
from pathlib import Path


dir=Path.home() / f"tmp/resnet50/CUB2011/123456/"
dic=torch.load(dir/ f"SlDD_Selection_50.pt")

print (dic)

#if 'linear.selection' in dic.keys():
    #print("key 'linear.selection' exist")
#else:
    #print("no such key")




