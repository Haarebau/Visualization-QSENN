def get_default_img_optimizer(model):
    raise NotImplementedError("TODO: Implement get_default_img_optimizer")
    pass

def get_default_img_schedule(default_img_optimizer):
    raise NotImplementedError("TODO: Implement get_default_img_schedule")
    pass